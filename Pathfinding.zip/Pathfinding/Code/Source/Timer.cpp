#include "Timer.h"

Timer::Timer()
{
	startTimePoint = std::chrono::high_resolution_clock::now();
}

Timer::~Timer()
{
	Stop();
}

void Timer::Stop()
{
	auto currentTimePoint = std::chrono::high_resolution_clock::now();
	auto start = std::chrono::time_point_cast<std::chrono::microseconds>(startTimePoint).time_since_epoch().count();
	auto end = std::chrono::time_point_cast<std::chrono::microseconds>(currentTimePoint).time_since_epoch().count();
	auto duration = end - start;
	double ms = duration * 0.001f;
	std::cout << "Duration : " << ms << " ms" << std::endl;
}
