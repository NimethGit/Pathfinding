#include "GridHelper.h"

[[nodiscard]] bool GridHelper::IsGridPositionWithinGrid(const std::pair<int, int>& GridPosition, const std::pair<int,int>& GridDimensions) noexcept
{
    if (GridPosition.first >= 0 && GridPosition.first < GridDimensions.first)
        if (GridPosition.second >= 0 && GridPosition.second < GridDimensions.second)
            return true;

    return false;
}

[[nodiscard]] bool GridHelper::IsGridPositionWithinGrid(const GridPosition& GridPosition, const std::pair<int, int>& GridDimensions) noexcept
{
    if (GridPosition.x >= 0 && GridPosition.x < GridDimensions.first)
        if (GridPosition.y >= 0 && GridPosition.y < GridDimensions.second)
            return true;

    return false;
}

[[nodiscard]] int GridHelper::ConvertGridPositionToArrayIndex(const std::pair<int, int>& GridPosition, const std::pair<int, int>& GridDimensions) noexcept
{
    //Code standard dictates that our arrays are filled in row-major order
    //each row is given in order of increasing x-coordinate, and the rows are given in order of increasing y-coordinate.

    int numberOfRows = GridPosition.second;
    int numberOfColumns = GridPosition.first;
    int gridWidth = GridDimensions.first;

    int index = (numberOfRows * gridWidth) + (numberOfColumns);
    return index;
}

[[nodiscard]] int GridHelper::ConvertGridPositionToArrayIndex(const GridPosition& GridPosition, const std::pair<int, int>& GridDimensions) noexcept
{
    //Code standard dictates that our arrays are filled in row-major order
    //each row is given in order of increasing x-coordinate, and the rows are given in order of increasing y-coordinate.

    int numberOfRows = GridPosition.y;
    int numberOfColumns = GridPosition.x;
    int gridWidth = GridDimensions.first;

    int index = (numberOfRows * gridWidth) + (numberOfColumns);
    return index;
}

[[nodiscard]] std::pair<int, int> GridHelper::ConvertArrayIndexToGridPosition(const int& Index, const std::pair<int, int>& GridDimensions) noexcept
{
    //Code standard dictates that our arrays are filled in row-major order
    //each row is given in order of increasing x-coordinate, and the rows are given in order of increasing y-coordinate.

    int gridWidth = GridDimensions.first;

    int yPosition = Index / gridWidth;
    int xPosition = Index - (yPosition * gridWidth);

    std::pair<int, int> GridPosition(xPosition, yPosition);

    return GridPosition;
}
