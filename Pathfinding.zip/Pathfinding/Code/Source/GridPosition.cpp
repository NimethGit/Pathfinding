#include "GridPosition.h"

GridPosition::GridPosition()
	:x(-1), y(-1)
{
}

GridPosition::GridPosition(int x, int y)
	:x(x), y(y)
{
}

GridPosition::GridPosition(std::pair<int, int> gridPosition)
	:x(gridPosition.first), y(gridPosition.second)
{
}

GridPosition GridPosition::Add(const GridPosition& other) const
{
	return GridPosition(x + other.x, y + other.y);
}

GridPosition GridPosition::operator+(const GridPosition& other) const
{
	return Add(other);
}

bool GridPosition::Equals(const GridPosition& other) const
{
	return x == other.x && y == other.y;
}

bool GridPosition::operator==(const GridPosition& other) const
{
	return Equals(other);
}

bool GridPosition::Equals(const std::pair<int, int>& other) const
{
	return x == other.first && y == other.second;
}

bool GridPosition::operator==(const std::pair<int, int>& other) const
{
	return Equals(other);
}

bool GridPosition::operator!=(const GridPosition& other) const
{
	return !Equals(other);
}

std::ostream& operator<<(std::ostream& stream, const GridPosition& position)
{
	stream << "[" << position.x << "," << position.y << "]";
	return stream;
}