#include "AStarGrid.h"

AStarGrid::AStarGrid(const std::vector<int>& Map, const std::pair<int, int> GridDimensions) noexcept
    :map(Map),gridDimensions(GridDimensions), targetPosition(), startPosition()
{
}

AStarGrid::~AStarGrid()
{
    for (auto& nodePair : nodesCreated) //Unsure if noexcept or not
    {
        delete nodePair.second;
    }

    nodesCreated.clear(); //noexcept
    openNodes.clear(); //noexcept
}

[[nodiscard]] bool AStarGrid::FindPath(const std::pair<int, int> StartPosition, const std::pair<int, int> TargetPosition, std::vector<int>& OutPath)
{
    targetPosition = TargetPosition;
    startPosition = StartPosition;

    auto const& SortByNodeLookupPriority = [](AStarNode* left, AStarNode* right) 
    {        
        return left->hCost > right->hCost;
    };       

    AStarNode* StartNode = new AStarNode(StartPosition);
    nodesCreated[StartPosition] = StartNode;

    std::vector<AStarNode*>* lowestBucket = &openNodes[StartNode->GetFCost()];
    lowestBucket->push_back(StartNode);

    while (lowestBucket->empty() == false) 
    {
        AStarNode* currentNode = lowestBucket->front();
        std::pop_heap(lowestBucket->begin(), lowestBucket->end(), SortByNodeLookupPriority); 

        if (currentNode->gridPosition == TargetPosition)
        {
            SavePathToFoundTarget(OutPath, *currentNode);
            return true;
        }

        lowestBucket->pop_back(); 

        currentNode->isInClosed = true; 
        currentNode->isInOpen = false;

        AddTraversableNeighbours(*currentNode);

        for (auto& neighbour : currentNode->neighbours)
        {
            if (neighbour->isInClosed == true) { continue; }

            if (neighbour->isInOpen == false) // 'neighbour' is a newly created node 
            {
                neighbour->isInOpen = true;
                neighbour->parent = currentNode;

                std::vector<AStarNode*>* nodeBucket = &openNodes[neighbour->GetFCost()];
                nodeBucket->push_back(neighbour);

                if (neighbour->GetFCost() == currentNode->GetFCost()) //Only sort the current lowest Bucket.
                {
                    std::push_heap(nodeBucket->begin(), nodeBucket->end(), SortByNodeLookupPriority);
                }
                continue;
            }

            int newGCostToNeighbour = currentNode->gCost + 1; // '1' is the equivalent of a step on the grid. We don't allow diagonal movement which is why we can have it like this.
            if (newGCostToNeighbour < neighbour->gCost)
            {
                std::vector<AStarNode*>* nodeBucket = &openNodes[neighbour->GetFCost()];
                nodeBucket->erase(std::find(nodeBucket->begin(), nodeBucket->end(), neighbour));
                UpdateNeighbourHeuristics(*neighbour, newGCostToNeighbour, *currentNode);
                nodeBucket = &openNodes[neighbour->GetFCost()];
                nodeBucket->push_back(neighbour);

                if (neighbour->GetFCost() == currentNode->GetFCost())
                {
                    std::push_heap(nodeBucket->begin(), nodeBucket->end(), SortByNodeLookupPriority);
                }
            }
        }

        if (!lowestBucket->empty()) { continue; }

        for (auto& bucket : openNodes)
        {
            if (!bucket.second.empty())
            {
                lowestBucket = &openNodes[bucket.first];
                std::make_heap(lowestBucket->begin(), lowestBucket->end(), SortByNodeLookupPriority);
                break;
            }
        }
    }

    return false;
}

inline void AStarGrid::AddTraversableNeighbours(AStarNode& NodeToAddNeighboursTo) noexcept
{
    GridPosition originalPosition = NodeToAddNeighboursTo.gridPosition;

    GridPosition north = GridPosition(0, 1);
    GridPosition south = GridPosition(0, -1);
    GridPosition east = GridPosition(1, 0);
    GridPosition west = GridPosition(-1, 0);

    TryToAddTraversableNeighbour(NodeToAddNeighboursTo, originalPosition + north);
    TryToAddTraversableNeighbour(NodeToAddNeighboursTo, originalPosition + south);
    TryToAddTraversableNeighbour(NodeToAddNeighboursTo, originalPosition + east);
    TryToAddTraversableNeighbour(NodeToAddNeighboursTo, originalPosition + west);
}

inline void AStarGrid::TryToAddTraversableNeighbour(AStarNode& NodeToAddNeighboursTo, const GridPosition& neighbourPosition) noexcept
{
    if (!GridHelper::IsGridPositionWithinGrid(neighbourPosition, gridDimensions)) { return; }
    if (map[GridHelper::ConvertGridPositionToArrayIndex(neighbourPosition, gridDimensions)] == 0) { return; } //Not traversable

    if (nodesCreated.find(neighbourPosition) == nodesCreated.end())
    {
        AStarNode* newNode = new AStarNode(neighbourPosition, NodeToAddNeighboursTo, NodeToAddNeighboursTo.gCost + 1,
            CalculateDistanceBetweenGridPositions(neighbourPosition, targetPosition));

        NodeToAddNeighboursTo.AddNeighbour(*newNode);
        newNode->parent = &NodeToAddNeighboursTo;
        nodesCreated[neighbourPosition] = newNode;
    }
    else
    {
        NodeToAddNeighboursTo.AddNeighbour(*nodesCreated[neighbourPosition]);
    }
}

[[nodiscard]] inline int AStarGrid::CalculateDistanceBetweenGridPositions(const GridPosition& NodePosition, const GridPosition& TargetPosition) const noexcept
{
    int xDifference = std::abs(NodePosition.x - TargetPosition.x);
    int yDifference = std::abs(NodePosition.y - TargetPosition.y);

    return xDifference + yDifference;
}

inline void AStarGrid::UpdateNeighbourHeuristics(AStarNode& Neighbour, const int NewGCost, const AStarNode& NewParent) noexcept
{
    Neighbour.gCost = NewGCost;
    Neighbour.parent = (AStarNode*)&NewParent;
}

void AStarGrid::SavePathToFoundTarget(std::vector<int>& OutPath, const AStarNode& Target)
{
    AStarNode* traversePathNode = (AStarNode*)&Target;

    while (traversePathNode->parent != nullptr)
    {
        OutPath.push_back(GridHelper::ConvertGridPositionToArrayIndex(traversePathNode->gridPosition, gridDimensions));
        traversePathNode = traversePathNode->parent;
    }

    std::reverse(OutPath.begin(), OutPath.end());
}

