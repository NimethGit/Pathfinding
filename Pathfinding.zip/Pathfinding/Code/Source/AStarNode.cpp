#include "AStarNode.h"

AStarNode::~AStarNode()
{
	parent = nullptr;
	neighbours.clear();
}

AStarNode::AStarNode(const std::pair<int, int> GridPosition) noexcept
	:gridPosition(GridPosition), neighbours(), parent(nullptr), isInOpen(false), isInClosed(false), gCost(0), hCost(0)
{
}

AStarNode::AStarNode(const std::pair<int, int> GridPosition, AStarNode& Parent, const int GCost, const int HCost) noexcept
	: gridPosition(GridPosition), neighbours(), parent(&Parent), isInOpen(false), isInClosed(false), gCost(GCost), hCost(HCost)
{
}

AStarNode::AStarNode(const GridPosition GridPosition) noexcept
	:gridPosition(GridPosition), neighbours(), parent(nullptr), isInOpen(false), isInClosed(false), gCost(0), hCost(0)
{
}

AStarNode::AStarNode(const GridPosition GridPosition, AStarNode& Parent, const int GCost, const int HCost) noexcept
	: gridPosition(GridPosition), neighbours(), parent(&Parent), isInOpen(false), isInClosed(false), gCost(GCost), hCost(HCost)
{
}

[[nodiscard]] int AStarNode::GetFCost() const noexcept
{
	return gCost + hCost;
}

void AStarNode::AddNeighbour(const AStarNode& Neighbour) noexcept
{
	neighbours.push_back((AStarNode*)&Neighbour);
}