#include <iostream>

#include "AStarGrid.h"

bool FindPath(std::pair<int, int> Start,
    std::pair<int, int> Target,
    const std::vector<int>& Map,
    std::pair<int, int> MapDimensions,
    std::vector<int>& OutPath)
{
    AStarGrid grid = AStarGrid(Map, MapDimensions);
    bool foundPath = grid.FindPath(Start, Target, (std::vector<int>&)OutPath);
    return foundPath;
}

int main([[maybe_unused]] int argc, [[maybe_unused]] char* argv[])
{
    std::vector<int> Map = { 1,1,1,1,0,1,0,1,0,1,1,1 };
    std::pair<int, int> MapDimensions = { 4,3 };
    std::pair<int, int> Start = { 0,0 };
    std::pair<int, int> Target = { 1,2 };
    std::vector<int> OutPath = {};

    bool foundPath = FindPath(Start, Target, Map, MapDimensions, OutPath);

    if (foundPath)
    {
        for (int i = 0; i < OutPath.size(); i++)
            std::cout << OutPath[i] << " ";
    }
    else
        std::cout << "Path not found";

    return 0;
}

