#pragma once
#include "GridPosition.h"

struct GridHelper
{
	[[nodiscard]] static bool IsGridPositionWithinGrid(const std::pair<int, int>& GridPosition, const std::pair<int, int>& GridDimensions) noexcept;
	[[nodiscard]] static bool IsGridPositionWithinGrid(const GridPosition& GridPosition, const std::pair<int, int>& GridDimensions) noexcept;

	[[nodiscard]] static int  ConvertGridPositionToArrayIndex(const std::pair<int, int>& GridPosition, const std::pair<int, int>& GridDimensions) noexcept;
	[[nodiscard]] static int  ConvertGridPositionToArrayIndex(const GridPosition& GridPosition, const std::pair<int, int>& GridDimensions) noexcept;

	[[nodiscard]] static std::pair<int, int> ConvertArrayIndexToGridPosition(const int& Index, const std::pair<int, int>& GridDimensions) noexcept;
};