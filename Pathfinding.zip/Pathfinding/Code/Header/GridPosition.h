#pragma once
#include <iostream>

struct GridPosition
{
	GridPosition();
	GridPosition(int x, int y);
	GridPosition(std::pair<int, int> gridPosition);

	GridPosition Add(const GridPosition& other) const;
	GridPosition operator+(const GridPosition& other) const;

	bool Equals(const GridPosition& other) const;
	bool operator==(const GridPosition& other) const;

	bool Equals(const std::pair<int, int>& other) const;
	bool operator==(const std::pair<int, int>& other) const;

	bool operator!=(const GridPosition& other) const;

	int x;
	int y;
};

namespace std {
	template <>
	struct hash<GridPosition>
	{
		size_t operator()(const GridPosition& p) const
		{
			return hash<long long>{}((long long)(p.y * p.x) + p.x);
		}
	};
}

std::ostream& operator<<(std::ostream& stream, const GridPosition& position); //Just so we can print out the GridPosition more easily