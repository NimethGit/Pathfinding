#pragma once
#include <vector>

#include "GridPosition.h"

struct AStarNode
{
	AStarNode() = delete;
	~AStarNode();
	explicit AStarNode(const std::pair<int, int> GridPosition) noexcept;
	explicit AStarNode(const std::pair<int, int> GridPosition, AStarNode& Parent, const int GCost, const int HCost) noexcept;

	explicit AStarNode(const GridPosition GridPosition) noexcept;
	explicit AStarNode(const GridPosition GridPosition, AStarNode& Parent, const int GCost, const int HCost) noexcept;

	const GridPosition gridPosition;
	std::vector<AStarNode*> neighbours;
	AStarNode* parent;

	bool isInOpen;
	bool isInClosed;
	int gCost;
	int hCost;

	[[nodiscard]] int GetFCost() const noexcept;
	void AddNeighbour(const AStarNode& Neighbour) noexcept;
};