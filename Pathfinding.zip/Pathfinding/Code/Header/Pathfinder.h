#pragma once
#include <vector>

class Pathfinder
{
public:
	[[nodiscard]] virtual bool FindPath(const std::pair<int, int> Start, const std::pair<int, int> Target, std::vector<int>& OutPath) = 0;
};