#pragma once
#include <algorithm>
#include <vector>
#include <map>
#include <unordered_map>

#include "GridHelper.h"
#include "Pathfinder.h"
#include "AStarNode.h"
#include "GridPosition.h"

struct AStarGrid : public Pathfinder
{
	AStarGrid() = delete;
	~AStarGrid(); //noexcept?
	explicit AStarGrid(const std::vector<int>& Map, const std::pair<int, int> GridDimensions) noexcept;

	[[nodiscard]] bool FindPath(const std::pair<int, int> Start, const std::pair<int, int> Target, std::vector<int>& OutPath) override;

private:
	const std::vector<int>& map;
	const std::pair<int, int> gridDimensions;
	GridPosition targetPosition;
	GridPosition startPosition;

	std::unordered_map<GridPosition, AStarNode*> nodesCreated;
	std::map<int, std::vector<AStarNode*>> openNodes;

	inline void AddTraversableNeighbours(AStarNode& NodeToAddNeighboursTo) noexcept;
	inline void TryToAddTraversableNeighbour(AStarNode& NodeToAddNeighboursTo, const GridPosition& neighbourPosition) noexcept;

	[[nodiscard]] inline int CalculateDistanceBetweenGridPositions(const GridPosition& NodePosition, const GridPosition& TargetPosition) const noexcept;
	inline void UpdateNeighbourHeuristics(AStarNode& Neighbour, const int NewGCost, const AStarNode& NewParent) noexcept;

	void SavePathToFoundTarget(std::vector<int>& OutPath, const AStarNode& Target);
};